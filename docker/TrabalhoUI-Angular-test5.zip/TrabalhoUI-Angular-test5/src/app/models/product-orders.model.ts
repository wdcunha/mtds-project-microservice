import {ProductOrder} from './product-order.model';

export class ProductOrders {
    productOrders: ProductOrder[] = [];
}
