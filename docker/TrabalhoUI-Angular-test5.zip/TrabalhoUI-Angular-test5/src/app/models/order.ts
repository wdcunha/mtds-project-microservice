export interface Order {
  id: number;
  amount: number;
  date: string;

}
