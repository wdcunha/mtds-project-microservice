export interface CartToOrder {

  amount: number;
}
