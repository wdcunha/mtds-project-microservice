export interface Product {
  id: number;
  productName: string;
  price: number;
  pictureUrl: string;
}
